<?php
    $DATABASE_HOST = "database-1.ceggbiv2fjia.us-east-1.rds.amazonaws.com";
    $DATABASE_USER = "adminroot";
    $DATABASE_PASS = "welcome_123";
    $DATABASE_NAME = "docRegform";

    $conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

    if(!$conn) {
        echo "Connection Failed";
    }
?>